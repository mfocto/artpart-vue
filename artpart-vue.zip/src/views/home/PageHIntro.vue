<!-- PageHIntro.vue -->
<template>

    <PageIntro msg="Intro 페이지 입니다."/>

</template>

<script>
// @ is an alias to /src
import PageIntro from '@/components/common/PageIntro.vue'

export default {
  name: 'PageHIntro',
  components: {
    PageIntro
  }
}


</script>

